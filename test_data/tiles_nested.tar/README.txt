This is a test tar archive with nested tiles
